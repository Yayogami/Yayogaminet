//! Browser-only experiment. Deliberately refuses native builds with direct sockets.
#[cfg(not(target_arch = "wasm32"))]
compile_error!("This proof must be built for wasm32-unknown-unknown");

use std::{cell::{Cell, RefCell}, rc::Rc, time::Duration};
use anyhow::{Result, anyhow, ensure};
use iroh::{Endpoint, EndpointAddr, EndpointId, RelayMap, RelayUrl, endpoint::{Connection, QuicTransportConfig, RelayMode, presets}};
use serde::{Deserialize, Serialize};
use wasm_bindgen::prelude::*;
use wasm_bindgen_futures::spawn_local;

const ALPN: &[u8] = b"yayo/iroh-browser-proof/1";
// Public generation locators must never negotiate private-invitation admission.
const DISCOVERY_ALPN: &[u8] = b"yayo/iroh-browser-discovery/1";
const RELAY: &str = "https://use1-1.relay.n0.iroh.link./";
const LIMIT: usize = 8192;
const MAX_ADMISSIONS: usize = 4;

struct Inner {
    endpoint: Endpoint,
    token: String,
    connection: RefCell<Option<Connection>>,
    used: Cell<bool>,
    closed: Cell<bool>,
    callback: js_sys::Function,
    manual: bool,
    discovery: bool,
    discovery_room: RefCell<String>,
    pending_peer: RefCell<Option<(u64, Connection)>>,
    next_request: Cell<u64>,
}
impl Inner {
    fn emit(&self, kind: &str, value: &str) {
        if !self.closed.get() {
            let event = serde_json::json!({"type":kind,"value":value}).to_string();
            let _ = self.callback.call1(&JsValue::NULL, &JsValue::from_str(&event));
        }
    }
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Hello { token: String }

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct DiscoveryHello { room_id: String }

#[wasm_bindgen]
pub struct PrivacyNode(Rc<Inner>);

#[wasm_bindgen]
impl PrivacyNode {
    pub async fn start(token: String, host: bool, callback: js_sys::Function) -> Result<PrivacyNode, JsError> {
        Self::start_config(token, host, callback, false, false).await
    }

    pub async fn start_manual(token: String, callback: js_sys::Function) -> Result<PrivacyNode, JsError> {
        Self::start_config(token, true, callback, true, false).await
    }

    // room_id is PUBLIC routing/generation data, not an authentication secret.
    // Every host on this ALPN requires explicit approval of the TLS peer identity.
    pub async fn start_discovery(room_id: String, host: bool, callback: js_sys::Function) -> Result<PrivacyNode, JsError> {
        Self::start_config(room_id, host, callback, host, true).await
    }

    pub fn bind_discovery_room(&self, room_id: String) -> Result<(), JsError> {
        if self.0.closed.get() || !self.0.discovery || !self.0.manual || self.0.used.get() {
            return Err(JsError::new("Bind only an idle discovery host"));
        }
        if room_id.len() != 64 || !room_id.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)) {
            return Err(JsError::new("Invalid room generation"));
        }
        self.0.discovery_room.replace(room_id);
        Ok(())
    }

    pub fn approve_pending(&self, request: String, peer: String) -> Result<(), JsError> {
        let conn = self.take_pending(&request, &peer)?;
        attach(self.0.clone(), conn);
        Ok(())
    }

    pub fn reject_pending(&self, request: String, peer: String) -> Result<(), JsError> {
        let conn = self.take_pending(&request, &peer)?;
        conn.close(1u8.into(), b"host declined");
        self.0.used.set(false);
        self.0.emit("waiting", "Host remains available");
        Ok(())
    }
}

impl PrivacyNode {
    fn take_pending(&self, request: &str, peer: &str) -> Result<Connection, JsError> {
        if self.0.closed.get() || !self.0.manual { return Err(JsError::new("No pending admission")); }
        let mut pending = self.0.pending_peer.borrow_mut();
        let Some((serial, conn)) = pending.as_ref() else { return Err(JsError::new("No pending admission")); };
        if serial.to_string() != request || conn.remote_id().to_string() != peer {
            return Err(JsError::new("Pending peer changed"));
        }
        if conn.close_reason().is_some() { return Err(JsError::new("Pending peer disconnected")); }
        Ok(pending.take().unwrap().1)
    }

    async fn start_config(token: String, host: bool, callback: js_sys::Function, manual: bool, discovery: bool) -> Result<PrivacyNode, JsError> {
        console_error_panic_hook::set_once();
        if token.len() != 64 || !token.bytes().all(|c| c.is_ascii_hexdigit()) {
            return Err(JsError::new("Invalid session token"));
        }
        let relay: RelayUrl = RELAY.parse()?;
        // No DNS/pkarr publishing or lookup. Invitations contain an endpoint key only.
        // The WASM target has no native IP transports; no custom transport is installed.
        let endpoint = Endpoint::builder(presets::N0)
            // Small reliable messages only. Apply limits before authentication too,
            // including while a connection waits for explicit host approval.
            .transport_config(QuicTransportConfig::builder()
                .max_concurrent_bidi_streams(16u32.into())
                .max_concurrent_uni_streams(0u32.into())
                .stream_receive_window(8192u32.into())
                .receive_window(65536u32.into())
                .send_window(65536)
                .datagram_receive_buffer_size(None)
                .build())
            .clear_address_lookup()
            .relay_mode(RelayMode::Custom(RelayMap::from(relay)))
            .alpns(if host { vec![if discovery { DISCOVERY_ALPN } else { ALPN }.to_vec()] } else { vec![] })
            .bind().await.map_err(js_err)?;
        if n0_future::time::timeout(Duration::from_secs(25), endpoint.online()).await.is_err() {
            endpoint.close().await;
            return Err(JsError::new("Relay unavailable; no direct fallback"));
        }
        let discovery_room = RefCell::new(token.clone());
        let inner = Rc::new(Inner { endpoint, token, connection: RefCell::new(None), used: Cell::new(false), closed: Cell::new(false), callback, manual, discovery, discovery_room, pending_peer: RefCell::new(None), next_request: Cell::new(0) });
        if host {
            let owner = inner.clone();
            spawn_local(async move {
                let pending = Rc::new(Cell::new(0usize));
                while let Some(incoming) = owner.endpoint.accept().await {
                    if owner.closed.get() || owner.used.get() || pending.get() >= MAX_ADMISSIONS {
                        incoming.refuse(); continue;
                    }
                    // Bound parallel work without letting one stalled hello block every peer.
                    pending.set(pending.get() + 1);
                    let pending = pending.clone();
                    let owner = owner.clone();
                    spawn_local(async move {
                    let reserved = Cell::new(false);
                    let outcome = n0_future::time::timeout(Duration::from_secs(10), async {
                        let conn = incoming.await?;
                        let result: Result<()> = async {
                            let (mut send, mut recv) = conn.accept_bi().await?;
                            let bytes = recv.read_to_end(256).await?;
                            if owner.discovery {
                                let hello: DiscoveryHello = serde_json::from_slice(&bytes)?;
                                ensure!(hello.room_id == *owner.discovery_room.borrow(), "Stale room generation");
                            } else {
                                let hello: Hello = serde_json::from_slice(&bytes)?;
                                ensure!(hello.token == owner.token, "Invalid invitation");
                            }
                            ensure!(!owner.closed.get(), "Session closed");
                            // Reserve synchronously before awaiting the acknowledgement write.
                            // Concurrent valid hellos must never both attach to this session.
                            ensure!(!owner.used.replace(true), "Session already admitted a peer");
                            reserved.set(true);
                            send.write_all(b"ok").await?;
                            send.finish()?;
                            Ok(())
                        }.await;
                        if let Err(e) = result { conn.close(1u8.into(), b"admission rejected"); return Err(e); }
                        Ok::<_, anyhow::Error>(conn)
                    }).await;
                    pending.set(pending.get() - 1);
                    match outcome {
                        Ok(Ok(conn)) if !owner.closed.get() => {
                            if owner.manual { hold_pending(owner.clone(), conn); }
                            else { attach(owner.clone(), conn); }
                        },
                        Ok(Ok(conn)) => conn.close(0u8.into(), b"session ended"),
                        _ => {
                            if reserved.get() { owner.used.set(false); }
                            owner.emit("rejected", "Unauthenticated or timed-out connection rejected");
                        }
                    }
                    });
                }
            });
        }
        Ok(PrivacyNode(inner))
    }
}

#[wasm_bindgen]
impl PrivacyNode {
    pub fn endpoint_id(&self) -> String { self.0.endpoint.id().to_string() }

    // Domain-separated directory proof; never export endpoint secret key bytes.
    pub fn sign_directory_challenge(&self, audience: String, challenge: String, request_hash: String) -> Result<Vec<u8>, JsError> {
        if self.0.closed.get() { return Err(JsError::new("Session closed")); }
        if audience.is_empty() || audience.len() > 200 || !audience.bytes().all(|b| b.is_ascii_graphic()) {
            return Err(JsError::new("Invalid directory audience"));
        }
        for value in [&challenge, &request_hash] {
            if value.len() != 64 || !value.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)) {
                return Err(JsError::new("Invalid directory proof fields"));
            }
        }
        let message = format!("iroh-room-directory-v1\n{}\n{}\n{}\n{}", audience, self.0.endpoint.id(), challenge, request_hash);
        Ok(self.0.endpoint.secret_key().sign(message.as_bytes()).to_bytes().to_vec())
    }

    pub async fn connect(&self, id: String) -> Result<(), JsError> {
        if self.0.used.replace(true) { return Err(JsError::new("Start a fresh session before reconnecting")); }
        let outcome = n0_future::time::timeout(Duration::from_secs(25), async {
            let id: EndpointId = id.parse()?;
            let addr = EndpointAddr::new(id).with_relay_url(RELAY.parse()?);
            let conn = self.0.endpoint.connect(addr, if self.0.discovery { DISCOVERY_ALPN } else { ALPN }).await?;
            let (mut send, mut recv) = conn.open_bi().await?;
            let hello = if self.0.discovery {
                serde_json::to_vec(&DiscoveryHello { room_id: self.0.discovery_room.borrow().clone() })?
            } else { serde_json::to_vec(&Hello { token: self.0.token.clone() })? };
            send.write_all(&hello).await?;
            send.finish()?;
            ensure!(recv.read_to_end(16).await? == b"ok", "Session rejected");
            Ok::<_, anyhow::Error>(conn)
        }).await.map_err(|_| JsError::new("Connection timed out; start a fresh session"))?;
        attach(self.0.clone(), outcome.map_err(js_err)?);
        Ok(())
    }

    pub async fn send(&self, text: String) -> Result<(), JsError> {
        if text.is_empty() || text.len() > 4096 { return Err(JsError::new("Messages must contain 1–4096 UTF-8 bytes")); }
        let conn = self.0.connection.borrow().clone().ok_or_else(|| JsError::new("No authenticated peer"))?;
        n0_future::time::timeout(Duration::from_secs(15), async {
            let (mut send, mut recv) = conn.open_bi().await?;
            send.write_all(text.as_bytes()).await?;
            send.finish()?;
            ensure!(recv.read_to_end(16).await? == b"ok", "Missing acknowledgement");
            Ok::<_, anyhow::Error>(())
        }).await.map_err(|_| JsError::new("Delivery unknown: acknowledgement timed out"))?.map_err(js_err)
    }

    pub async fn close(&self) {
        self.0.closed.set(true);
        if let Some((_, conn)) = self.0.pending_peer.borrow_mut().take() { conn.close(0u8.into(), b"session ended"); }
        if let Some(conn) = self.0.connection.borrow_mut().take() { conn.close(0u8.into(), b"session ended"); }
        self.0.endpoint.close().await;
    }
}

fn hold_pending(owner: Rc<Inner>, conn: Connection) {
    let Some(serial) = owner.next_request.get().checked_add(1) else {
        conn.close(1u8.into(), b"request limit");
        owner.used.set(false);
        return;
    };
    owner.next_request.set(serial);
    let event = serde_json::json!({"requestId":serial.to_string(),"peerId":conn.remote_id().to_string()}).to_string();
    let monitored = conn.clone();
    owner.pending_peer.replace(Some((serial, conn)));
    owner.emit("pending", &event);
    spawn_local(async move {
        let _ = n0_future::time::timeout(Duration::from_secs(120), monitored.closed()).await;
        let expired = {
            let mut pending = owner.pending_peer.borrow_mut();
            if pending.as_ref().is_some_and(|(id, _)| *id == serial) { pending.take() } else { None }
        };
        if let Some((_, conn)) = expired {
            conn.close(1u8.into(), b"approval expired");
            owner.used.set(false);
            owner.emit("waiting", "Pending admission expired");
        }
    });
}

fn attach(owner: Rc<Inner>, conn: Connection) {
    owner.used.set(true);
    owner.connection.replace(Some(conn.clone()));
    owner.emit("connected", &conn.remote_id().to_string());
    spawn_local(async move {
        let result: Result<()> = async {
            loop {
                let (mut send, mut recv) = conn.accept_bi().await?;
                let bytes = n0_future::time::timeout(Duration::from_secs(15), recv.read_to_end(LIMIT)).await??;
                ensure!(!bytes.is_empty() && bytes.len() <= 4096, "Invalid message size");
                let text = String::from_utf8(bytes)?;
                owner.emit("message", &text);
                send.write_all(b"ok").await?;
                send.finish()?;
            }
        }.await;
        owner.connection.borrow_mut().take();
        conn.close(0u8.into(), b"session stopped");
        owner.emit("disconnected", &result.err().unwrap_or_else(|| anyhow!("Peer ended session")).to_string());
    });
}

fn js_err(e: impl std::fmt::Display) -> JsError { JsError::new(&e.to_string()) }
