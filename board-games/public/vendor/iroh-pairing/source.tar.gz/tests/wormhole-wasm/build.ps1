param([switch]$Audit)
$ErrorActionPreference = 'Stop'
$project = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$env:RUSTUP_HOME = Join-Path $project 'tools/rustup'
$env:CARGO_HOME = Join-Path $project 'tools/cargo'
$buildArgs = @('build', '--locked', '--offline', '--manifest-path', (Join-Path $PSScriptRoot 'Cargo.toml'), '--target', 'wasm32-unknown-unknown', '--release', '--no-default-features')
$output = Join-Path $project 'prototype/mailbox-wasm'
if ($Audit) { $buildArgs += @('--features', 'audit'); $output = Join-Path $PSScriptRoot 'pkg' }
& (Join-Path $project 'tools/cargo/bin/cargo.exe') @buildArgs
if ($LASTEXITCODE -ne 0) { throw 'Mailbox feasibility build failed' }
& (Join-Path $project 'tools/wasm-bindgen/wasm-bindgen.exe') (Join-Path $PSScriptRoot 'target/wasm32-unknown-unknown/release/wormhole_feasibility.wasm') --target web --out-dir $output
if ($LASTEXITCODE -ne 0) { throw 'Mailbox feasibility bindings failed' }
