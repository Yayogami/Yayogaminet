use magic_wormhole::{Code, Password};

const ALPHABET: &[u8; 32] = b"0123456789abcdefghjkmnpqrstvwxyz";
pub const MAX_NAMEPLATE: u32 = 32767;

pub fn secret() -> Result<String, ()> {
    let mut bytes = [0u8; 7];
    getrandom::getrandom(&mut bytes).map_err(|_| ())?;
    // 32 divides 256: no modulo bias. Exactly 35 independent random secret bits.
    Ok(bytes.iter().map(|byte| ALPHABET[(byte & 31) as usize] as char).collect())
}

fn valid_secret(value: &str) -> bool {
    value.len() == 7 && value.bytes().all(|byte| ALPHABET.contains(&byte))
}

pub fn password(value: String) -> Result<Password, ()> {
    if !valid_secret(&value) { return Err(()); }
    // Generation uses the CSPRNG above; guessing heuristics would reject some
    // equally likely random strings. On join this is the peer's claimed secret.
    Ok(unsafe { Password::new_unchecked(value) })
}

pub fn encode(code: &Code) -> Result<String, ()> {
    let name = code.nameplate().to_string();
    let number: u32 = name.parse().map_err(|_| ())?;
    if number == 0 || number > MAX_NAMEPLATE || number.to_string() != name { return Err(()); }
    let secret: String = code.password().into();
    if !valid_secret(&secret) { return Err(()); }
    let prefix: String = [10, 5, 0].iter().map(|shift| ALPHABET[((number >> shift) & 31) as usize] as char).collect();
    Ok(format!("{prefix}{secret}"))
}

pub fn decode(value: &str) -> Result<Code, ()> {
    if value.len() != 10 || !value.bytes().all(|byte| ALPHABET.contains(&byte)) { return Err(()); }
    let number = value.as_bytes()[..3].iter().fold(0u32, |n, byte| n * 32 + ALPHABET.iter().position(|c| c == byte).unwrap() as u32);
    if number == 0 { return Err(()); }
    Ok(Code::from_components(number.to_string().parse().map_err(|_| ())?, password(value[3..].to_owned())?))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn routing_boundaries_round_trip() {
        for n in [1, 31, 32, 1023, 1024, MAX_NAMEPLATE] {
            let code = Code::from_components(n.to_string().parse().unwrap(), password("0123456".into()).unwrap());
            let compact = encode(&code).unwrap();
            assert_eq!(compact.len(), 10);
            assert_eq!(decode(&compact).unwrap().to_string(), code.to_string());
        }
    }
    #[test]
    fn invalid_and_overflow_codes_are_rejected() {
        for value in ["", "0000123456", "001012345", "00101234567", "001012345i", "001012345O", "001012345U", "001012345é"] { assert!(decode(value).is_err()); }
        for n in ["0", "32768", "001"] {
            if let Ok(name) = n.parse() {
                assert!(encode(&Code::from_components(name, password("0123456".into()).unwrap())).is_err());
            }
        }
    }
    #[test]
    fn generated_secret_has_exact_canonical_shape() {
        for _ in 0..64 { assert!(valid_secret(&secret().unwrap())); }
    }
}
