// Pairing-only WASM: no transit or direct networking. Extra fixture exports
// require the explicit audit feature and are excluded from the release artifact.
use magic_wormhole::{AppConfig, AppID, MailboxConnection, Wormhole, WormholeError};
use std::borrow::Cow;
use wasm_bindgen::prelude::*;
mod short_code;

fn config() -> AppConfig<u32> {
    AppConfig {
        id: AppID::new("yayogami.net/iroh-mailbox-feasibility-v1"),
        rendezvous_url: Cow::Borrowed("wss://relay.magic-wormhole.io/v1"),
        app_version: 1,
    }
}
fn safe_error(error: WormholeError) -> JsValue {
    JsValue::from_str(if matches!(error, WormholeError::PakeFailed) {
        "authentication failed"
    } else {
        "mailbox operation failed"
    })
}

#[cfg(feature = "audit")]
#[wasm_bindgen]
pub struct HostProbe {
    mailbox: MailboxConnection<u32>,
}

#[cfg(feature = "audit")]
#[wasm_bindgen]
impl HostProbe {
    pub fn code(&self) -> String { self.mailbox.code().to_string() }
    pub async fn exchange(self) -> Result<bool, JsValue> { exchange(self.mailbox, true).await }
    pub async fn open(self) -> Result<MailboxChannel, JsValue> {
        Ok(MailboxChannel { inner: Wormhole::connect(self.mailbox).await.map_err(safe_error)? })
    }
}

// One operation at a time; the mailbox worker supplies deadlines/cancellation.
#[wasm_bindgen]
pub struct MailboxChannel { inner: Wormhole }
#[wasm_bindgen]
impl MailboxChannel {
    pub async fn send(&mut self, text: String) -> Result<(), JsValue> {
        if text.len() > 512 { return Err(JsValue::from_str("handoff size limit")); }
        self.inner.send(text.into_bytes()).await.map_err(safe_error)
    }
    pub async fn receive(&mut self) -> Result<String, JsValue> {
        let bytes = self.inner.receive().await.map_err(safe_error)?;
        // Post-decryption bound only: upstream framing needs separate review.
        if bytes.len() > 512 { return Err(JsValue::from_str("handoff size limit")); }
        String::from_utf8(bytes).map_err(|_| JsValue::from_str("invalid handoff encoding"))
    }
    pub async fn close(self) -> Result<(), JsValue> { self.inner.close().await.map_err(safe_error) }
}

#[cfg(feature = "audit")]
#[wasm_bindgen]
pub async fn join_channel(code: String) -> Result<MailboxChannel, JsValue> {
    if code.len() > 256 { return Err(JsValue::from_str("invalid probe code")); }
    let code = code.parse().map_err(|_| JsValue::from_str("invalid probe code"))?;
    let mailbox = MailboxConnection::connect(config(), code, false).await.map_err(safe_error)?;
    Ok(MailboxChannel { inner: Wormhole::connect(mailbox).await.map_err(safe_error)? })
}

#[cfg(feature = "audit")]
#[wasm_bindgen]
pub async fn create_host() -> Result<HostProbe, JsValue> {
    // Native protocol format for this experiment, not a selected product code format.
    Ok(HostProbe { mailbox: MailboxConnection::create(config(), 4).await.map_err(safe_error)? })
}

#[cfg(feature = "audit")]
#[wasm_bindgen]
pub async fn join_probe(code: String) -> Result<bool, JsValue> {
    if code.len() > 256 { return Err(JsValue::from_str("invalid probe code")); }
    let code = code.parse().map_err(|_| JsValue::from_str("invalid probe code"))?;
    let mailbox = MailboxConnection::connect(config(), code, false).await.map_err(safe_error)?;
    exchange(mailbox, false).await
}

#[cfg(feature = "audit")]
async fn exchange(mailbox: MailboxConnection<u32>, host: bool) -> Result<bool, JsValue> {
    let mut wormhole = Wormhole::connect(mailbox).await.map_err(safe_error)?;
    let sent = if host { b"iroh-mailbox-host-probe".as_slice() } else { b"iroh-mailbox-guest-probe".as_slice() };
    let expected = if host { b"iroh-mailbox-guest-probe".as_slice() } else { b"iroh-mailbox-host-probe".as_slice() };
    wormhole.send(sent.to_vec()).await.map_err(safe_error)?;
    let received = wormhole.receive().await.map_err(safe_error)?;
    let matched = received == expected;
    wormhole.close().await.map_err(safe_error)?;
    Ok(matched)
}

fn compact_config() -> AppConfig<u32> {
    config().id(AppID::new("yayogami.net/iroh-compact-pairing-feasibility-v1"))
}
fn invalid_code() -> JsValue { JsValue::from_str("invalid ten-character code") }

#[wasm_bindgen]
pub struct CompactHost { mailbox: MailboxConnection<u32>, code: String }
#[wasm_bindgen]
impl CompactHost {
    pub fn code(&self) -> String { self.code.clone() }
    pub async fn open(self) -> Result<MailboxChannel, JsValue> {
        Ok(MailboxChannel { inner: Wormhole::connect_retaining_nameplate(self.mailbox).await.map_err(safe_error)? })
    }
    pub async fn cancel(self) -> Result<(), JsValue> {
        self.mailbox.shutdown(magic_wormhole::Mood::Lonely).await.map_err(safe_error)
    }
}
async fn compact_host(mailbox: MailboxConnection<u32>) -> Result<CompactHost, JsValue> {
    match short_code::encode(mailbox.code()) {
        Ok(code) => Ok(CompactHost { mailbox, code }),
        Err(_) => {
            let _ = mailbox.shutdown(magic_wormhole::Mood::Errory).await;
            Err(invalid_code())
        }
    }
}
#[wasm_bindgen]
pub async fn create_compact_host() -> Result<CompactHost, JsValue> {
    let password = short_code::password(short_code::secret().map_err(|_| invalid_code())?).map_err(|_| invalid_code())?;
    compact_host(MailboxConnection::create_with_password(compact_config(), password).await.map_err(safe_error)?).await
}
#[wasm_bindgen]
pub async fn join_compact(code: String) -> Result<MailboxChannel, JsValue> {
    let code = short_code::decode(&code).map_err(|_| invalid_code())?;
    let mailbox = MailboxConnection::connect(compact_config(), code, false).await.map_err(safe_error)?;
    Ok(MailboxChannel { inner: Wormhole::connect_retaining_nameplate(mailbox).await.map_err(safe_error)? })
}

// Observational and forced-reuse hooks for the isolated lifecycle harness ONLY.
// Production creation must use atomic server allocation, never check-then-claim.
#[cfg(feature = "audit")]
#[wasm_bindgen]
pub async fn compact_nameplate_reserved(code: String) -> Result<bool, JsValue> {
    let nameplate = short_code::decode(&code).map_err(|_| invalid_code())?.nameplate();
    MailboxConnection::nameplate_claimed(compact_config(), &nameplate).await.map_err(safe_error)
}
#[cfg(feature = "audit")]
#[wasm_bindgen]
pub async fn test_reclaim_compact_host(previous_code: String) -> Result<CompactHost, JsValue> {
    let old = short_code::decode(&previous_code).map_err(|_| invalid_code())?;
    if compact_nameplate_reserved(previous_code).await? { return Err(JsValue::from_str("nameplate still reserved")); }
    let old_secret: String = old.password().into();
    let new_secret = short_code::secret().map_err(|_| invalid_code())?;
    // A collision is an error, not a reason to reuse a known pairing secret.
    if new_secret == old_secret { return Err(JsValue::from_str("pairing secret collision")); }
    let code = magic_wormhole::Code::from_components(old.nameplate(), short_code::password(new_secret).map_err(|_| invalid_code())?);
    compact_host(MailboxConnection::connect(compact_config(), code, true).await.map_err(safe_error)?).await
}
