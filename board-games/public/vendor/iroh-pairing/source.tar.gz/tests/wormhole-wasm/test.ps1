$ErrorActionPreference = 'Stop'
$project = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$env:RUSTUP_HOME = Join-Path $project 'tools/rustup'
$env:CARGO_HOME = Join-Path $project 'tools/cargo'
$env:LIBRARY_PATH = Join-Path $project 'tools/rustup/toolchains/stable-x86_64-pc-windows-gnu/lib/rustlib/x86_64-pc-windows-gnu/lib/self-contained'
$env:PATH = (Join-Path $project 'tools/w64devkit/bin') + ';' + $env:PATH
& (Join-Path $project 'tools/cargo/bin/cargo.exe') test --locked --offline --manifest-path (Join-Path $PSScriptRoot 'Cargo.toml') --lib
if ($LASTEXITCODE -ne 0) { throw 'Compact pairing codec tests failed' }
