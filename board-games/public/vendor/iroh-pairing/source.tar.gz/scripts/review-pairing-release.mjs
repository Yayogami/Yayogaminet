// Local release evidence only. No deployment or application credentials.
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {gzipSync,brotliCompressSync,constants} from 'node:zlib';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const root=fileURLToPath(new URL('../',import.meta.url));
const read=relative=>readFile(path.join(root,relative));
const json=async relative=>JSON.parse((await read(relative)).toString().replace(/^\uFEFF/,''));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const report={startedAt:new Date().toISOString(),scope:'Local pairing WASM exports, compressed sizes, and reachable wasm-target Cargo dependency inventory including build dependencies; not a published release or license clearance',inputs:[],artifacts:[],packages:[],failures:[]};
for(const file of ['Cargo.lock','src/lib.rs','tests/wormhole-wasm/Cargo.lock','tests/wormhole-wasm/Cargo.toml','tests/wormhole-wasm/src/lib.rs','tests/wormhole-wasm/vendor/magic-wormhole/src/core.rs','logs/iroh-release-metadata.json','logs/mailbox-release-metadata.json'])report.inputs.push({path:file,sha256:hash(await read(file))});
const forbidden=/hostprobe|create_host|join_channel|join_probe|compact_nameplate_reserved|test_reclaim_compact_host/i;
for(const [label,base] of [['mailbox-release','prototype/mailbox-wasm/wormhole_feasibility'],['mailbox-audit','tests/wormhole-wasm/pkg/wormhole_feasibility'],['iroh','prototype/wasm/iroh_browser_proof']]){
  const wasm=await read(base+'_bg.wasm'),js=await read(base+'.js');
  const exports=WebAssembly.Module.exports(await WebAssembly.compile(wasm)).map(e=>e.name);
  const api=Object.keys(await import(new URL('../'+base+'.js',import.meta.url))).sort();
  report.artifacts.push({label,wasm:{bytes:wasm.length,gzipBytes:gzipSync(wasm,{level:9}).length,brotliBytes:brotliCompressSync(wasm,{params:{[constants.BROTLI_PARAM_QUALITY]:11}}).length,sha256:hash(wasm)},javascript:{bytes:js.length,gzipBytes:gzipSync(js,{level:9}).length,sha256:hash(js)},api,wasmExports:exports});
  if(label==='mailbox-release'){
    assert.deepEqual(api,['CompactHost','MailboxChannel','create_compact_host','default','initSync','join_compact']);
    assert.equal(exports.some(name=>forbidden.test(name)),false,'Audit function exported by release WASM');
    for(const name of ['create_compact_host','join_compact','compacthost_code','compacthost_open','compacthost_cancel','mailboxchannel_send','mailboxchannel_receive','mailboxchannel_close'])assert.ok(exports.includes(name),`Missing release export: ${name}`);
  }
  if(label==='mailbox-audit')assert.ok(exports.includes('test_reclaim_compact_host'),'Audit positive control missing');
}
const packages=new Map();
for(const [component,file] of [['iroh','logs/iroh-release-metadata.json'],['mailbox','logs/mailbox-release-metadata.json']]){
  const metadata=await json(file),nodes=new Map(metadata.resolve.nodes.map(n=>[n.id,n])),reachable=new Set();
  const visit=id=>{if(reachable.has(id))return;reachable.add(id);for(const dep of nodes.get(id)?.dependencies??[])visit(dep);};visit(metadata.resolve.root);
  for(const pkg of metadata.packages.filter(p=>reachable.has(p.id)&&p.id!==metadata.resolve.root)){
    const key=`${pkg.name}@${pkg.version}`,entry=packages.get(key)??{name:pkg.name,version:pkg.version,license:pkg.license,source:pkg.source??'local fork',repository:pkg.repository,manifestPath:pkg.manifest_path,components:[],features:[],noticeFiles:[]};
    entry.components.push(component);entry.features=[...new Set([...entry.features,...nodes.get(pkg.id).features])].sort();packages.set(key,entry);
  }
}
async function notices(dir,base=dir,inside=false){
  const found=[];
  for(const entry of await readdir(dir,{withFileTypes:true})){
    const source=path.join(dir,entry.name),named=/^(licen[cs]e|unlicen[cs]e|copying|copyright|notice|author|contributor)(s|[._-]|$)/i.test(entry.name);
    if(entry.isSymbolicLink())throw Error('Unexpected symlink in dependency source');
    if(entry.isDirectory())found.push(...await notices(source,base,inside||named));
    else if(entry.isFile()&&(inside||named)){const bytes=await readFile(source);found.push({path:path.relative(base,source).replaceAll('\\','/'),sha256:hash(bytes),bytes:bytes.length});}
  }
  return found;
}
const upstream=await json('licenses/upstream/provenance.json'),release=await json('licenses/release/provenance.json');
async function supplementFile(base,file){
  const source=path.resolve(root,base,file.path),relative=path.relative(path.join(root,base),source);
  assert.ok(!relative.startsWith('..')&&!path.isAbsolute(relative),'Notice path leaves inventory');
  const bytes=await readFile(source);assert.equal(hash(bytes),file.sha256,'Notice provenance hash mismatch');
  return {path:`${base}/${file.path}`,sha256:file.sha256,bytes:bytes.length};
}
for(const entry of packages.values()){
  const dir=path.dirname(entry.manifestPath);entry.noticeFiles=await notices(dir);entry.supplementalNotices=[];
  const supplement=upstream.packages.find(p=>p.name===entry.name&&p.version===entry.version);
  if(supplement?.files.length){
    const vcs=JSON.parse(await readFile(path.join(dir,'.cargo_vcs_info.json'),'utf8'));
    assert.equal(vcs.git.sha1,supplement.commit);assert.equal(entry.repository,supplement.repository);
    for(const file of supplement.files)entry.supplementalNotices.push({...await supplementFile('licenses/upstream',file),basis:'pinned upstream source',url:file.url});
  }
  const standard=release.packages.find(p=>p.name===entry.name&&p.version===entry.version);
  if(standard){
    const vcs=JSON.parse(await readFile(path.join(dir,'.cargo_vcs_info.json'),'utf8'));
    assert.equal(vcs.git.sha1,standard.crateCommit);assert.equal(entry.license,standard.declaredLicense);assert.equal(hash(await readFile(entry.manifestPath)),standard.manifestSha256);
    entry.supplementalNotices.push({...await supplementFile('licenses/release',standard.file),basis:'previously reviewed standard text; not an upstream notice',license:standard.textLicense});
  }
  delete entry.manifestPath;
  report.packages.push(entry);
}
report.packages.sort((a,b)=>`${a.name}@${a.version}`.localeCompare(`${b.name}@${b.version}`));
report.noticeGaps=report.packages.filter(p=>!p.license||!(p.noticeFiles.length+p.supplementalNotices.length)).map(({name,version,license})=>({name,version,license}));
report.mailboxFeatures=report.packages.find(p=>p.name==='magic-wormhole')?.features;
assert.ok(report.mailboxFeatures);for(const feature of ['transit','transfer','forwarding','default'])assert.equal(report.mailboxFeatures.includes(feature),false,'Unexpected Wormhole transport feature');
if(process.argv.includes('--advisories')){
  report.advisories={source:'https://api.osv.dev/v1/querybatch',scope:'Published package/version matches; local fork queried against its upstream version. Does not audit fork changes or prove absence of vulnerabilities.',checkedAt:new Date().toISOString(),packages:[]};
  for(let offset=0;offset<report.packages.length;offset+=100){
    const batch=report.packages.slice(offset,offset+100);
    const response=await fetch(report.advisories.source,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({queries:batch.map(p=>({package:{name:p.name,ecosystem:'crates.io'},version:p.version}))}),signal:AbortSignal.timeout(30000)});
    if(!response.ok)throw Error(`OSV HTTP ${response.status}`);
    const data=await response.json();assert.equal(data.results?.length,batch.length,'Incomplete advisory response');
    data.results.forEach((result,index)=>report.advisories.packages.push({name:batch[index].name,version:batch[index].version,vulnerabilities:result.vulns??[]}));
  }
  report.advisories.matches=report.advisories.packages.filter(p=>p.vulnerabilities.length);
}
report.finishedAt=new Date().toISOString();
const file=`logs/pairing-release-review-${report.startedAt.replaceAll(':','-')}.json`;
await writeFile(path.join(root,file),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({file,artifacts:report.artifacts.map(({label,wasm,javascript})=>({label,wasm,javascript})),packages:report.packages.length,mailboxPackages:report.packages.filter(p=>p.components.includes('mailbox')).length,newMailboxPackages:report.packages.filter(p=>!p.components.includes('iroh')).length,noticeGaps:report.noticeGaps,advisoryMatches:report.advisories?.matches}));
