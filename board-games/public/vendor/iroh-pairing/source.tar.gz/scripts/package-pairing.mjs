// Build a local static candidate. No upload, site checkout or network access.
import {readFile,writeFile,mkdir,mkdtemp,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';
import {PAIRING_CSP,MAILBOX_CSP} from '../prototype/ui/security-policy.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const read=file=>readFile(path.join(root,file));
const json=async file=>JSON.parse((await read(file)).toString().replace(/^\uFEFF/,''));
const firstPartyLicense='Viral Public License (VPL)',licenseText=await read('LICENSE'),licenseScope=await read('LICENSING.md');
const licenseProvenance=await json('licenses/first-party/VPL.provenance.json');
assert.equal(licenseProvenance.shortName,'VPL');assert.equal(sha(licenseText),licenseProvenance.sha256,'First-party license changed from verified text');
const licenseReview={status:'compatibility unresolved',reviewCompleted:true,publication:'held by owner; VPL-only reaffirmed',reason:'Text/build review did not establish a VPL-only distribution route; dual licensing declined',scopeFile:'LICENSING.md',reviewFile:'audit/LICENSE-COMPATIBILITY-REVIEW.md'};
const reviewFile=process.argv[2]??'logs/pairing-release-review-2026-10-24T02-44-32.122Z.json',review=await json(reviewFile);
assert.deepEqual(review.advisories?.matches,[],'A successful dependency advisory review is required');
assert.deepEqual(review.noticeGaps,[],'Resolve notice inventory gaps first');
for(const input of review.inputs)assert.equal(sha(await read(input.path)),input.sha256,`Review input changed: ${input.path}`);
for(const [label,base] of [['iroh','prototype/wasm/iroh_browser_proof'],['mailbox-release','prototype/mailbox-wasm/wormhole_feasibility']]){
 const artifact=review.artifacts.find(a=>a.label===label);assert.ok(artifact);
 assert.equal(sha(await read(base+'_bg.wasm')),artifact.wasm.sha256,'Rebuilt WASM needs review');
 assert.equal(sha(await read(base+'.js')),artifact.javascript.sha256,'Rebuilt bindings need review');
}
const modules=['pairing-app','pairing-session','manual-client','manual-worker','room-protocol','mailbox-client','mailbox-worker','mailbox-worker-host','mailbox-frame'];
const runtime=[...modules.map(n=>`prototype/ui/${n}.mjs`),'prototype/ui/mailbox-frame.html',
 ...['compact-code','mailbox-handoff','mailbox-cleanup','directory-proof','room-credentials'].map(n=>`prototype/${n}.mjs`),
 'public/relay-policy.js','public/transport.js','public/style.css',
 ...['js','_bg.wasm'].map(ext=>'prototype/wasm/iroh_browser_proof'+(ext==='js'?'.js':ext)),
 ...['js','_bg.wasm'].map(ext=>'prototype/mailbox-wasm/wormhole_feasibility'+(ext==='js'?'.js':ext))];
const bytes=new Map();for(const file of runtime)bytes.set(file,await read(file));
const html=(await read('prototype/ui/pairing.html')).toString();
const meta=text=>/http-equiv="Content-Security-Policy" content="([^"]+)"/.exec(text)?.[1];
assert.equal(meta(html),PAIRING_CSP);assert.equal(meta(bytes.get('prototype/ui/mailbox-frame.html').toString()),MAILBOX_CSP);
const digest=createHash('sha256').update(html);for(const file of runtime)digest.update(file).update(bytes.get(file));
const version=digest.digest('hex').slice(0,24),prefix=`runtime/${version}`;
await mkdir(path.join(root,'dist'),{recursive:true});const output=await mkdtemp(path.join(root,'dist/pairing-')),site=path.join(output,'site'),source=path.join(output,'source');
const files=[],sourceFiles=[];
const safe=(base,relative)=>{assert.ok(!relative.includes('\\'));const result=path.resolve(base,relative),part=path.relative(base,result);assert.ok(part&&!part.startsWith('..')&&!path.isAbsolute(part),'Path leaves package');return result;};
async function save(base,relative,value,inventory){const data=Buffer.from(value),target=safe(base,relative);await mkdir(path.dirname(target),{recursive:true});await writeFile(target,data);inventory.push({path:relative,bytes:data.length,sha256:sha(data)});}
const saveSite=(file,data)=>save(site,file,data,files),saveSource=(file,data)=>save(source,file,data,sourceFiles);
for(const file of runtime)await saveSite(`${prefix}/${file}`,bytes.get(file));
await saveSite('index.html',html.replace('href="./style.css"',`href="./${prefix}/public/style.css"`).replace('src="./pairing-app.mjs"',`src="./${prefix}/prototype/ui/pairing-app.mjs"`).replace('<p class="hint">Local prototype. <a href="/">Full-invitation test</a></p>','<p class="hint"><a href="./SOURCE.html">Source and licenses</a></p>'));
await saveSite('.nojekyll','');await saveSite('.gitattributes','* -text\n');
await saveSite('LICENSE',licenseText);await saveSite('LICENSING.md',licenseScope);
await saveSite(licenseReview.reviewFile,await read(licenseReview.reviewFile));
await saveSite('licenses/VPL.provenance.json',JSON.stringify(licenseProvenance,null,2)+'\n');
const metadata=new Map();
for(const file of ['logs/iroh-release-metadata.json','logs/mailbox-release-metadata.json'])for(const p of (await json(file)).packages)metadata.set(`${p.name}@${p.version}`,p);
const inventory=[];
for(const entry of review.packages){
 const pkg=metadata.get(`${entry.name}@${entry.version}`);assert.ok(pkg);const dir=path.dirname(pkg.manifest_path),notices=[];
 for(const notice of entry.noticeFiles){const data=await readFile(safe(dir,notice.path));assert.equal(sha(data),notice.sha256);const target=`licenses/${entry.name}-${entry.version}/${notice.path}`;await saveSite(target,data);notices.push(target);}
 for(const [i,notice] of entry.supplementalNotices.entries()){const data=await read(notice.path);assert.equal(sha(data),notice.sha256);const target=`licenses/${entry.name}-${entry.version}/supplement-${i}-${path.basename(notice.path)}`;await saveSite(target,data);notices.push(target);}
 inventory.push({name:entry.name,version:entry.version,license:entry.license,source:entry.source,repository:entry.repository,components:entry.components,features:entry.features,notices,supplementProvenance:entry.supplementalNotices});
}
const release=await json('licenses/release/provenance.json');
for(const file of release.rust.files){const data=await read('licenses/release/'+file.path);assert.equal(sha(data),file.sha256);await saveSite('licenses/'+file.path,data);}
await saveSite('THIRD-PARTY.json',JSON.stringify({scope:'Reachable wasm-target graph including build dependencies; declarations and notice inventory, not legal clearance',packages:inventory},null,2)+'\n');
await saveSite('licenses/RELEASE-PROVENANCE.json',JSON.stringify(release,null,2)+'\n');
const sourceAllowlist=[...runtime.filter(f=>!f.endsWith('.wasm')&&!f.includes('/wasm/')&&!f.includes('/mailbox-wasm/')),
  'prototype/ui/pairing.html','prototype/ui/security-policy.mjs','Cargo.toml','Cargo.lock','.cargo/config.toml','src/lib.rs','build.ps1','package.json',
   'LICENSE','LICENSING.md','licenses/first-party/VPL.provenance.json',licenseReview.reviewFile,
 'scripts/clang.cmd','scripts/llvm-ar.cmd','scripts/cc.mjs','scripts/package-pairing.mjs','scripts/review-pairing-release.mjs',
 'tests/wormhole-wasm/Cargo.toml','tests/wormhole-wasm/Cargo.lock','tests/wormhole-wasm/build.ps1','tests/wormhole-wasm/test.ps1',
 'tests/wormhole-wasm/src/lib.rs','tests/wormhole-wasm/src/short_code.rs'];
for(const file of sourceAllowlist)await saveSource(file,await read(file));
async function copySourceTree(dir,relative){
 for(const entry of await readdir(dir,{withFileTypes:true})){
   assert.ok(!entry.isSymbolicLink(),'Unexpected source symlink');const next=relative+'/'+entry.name,absolute=path.join(dir,entry.name);
   if(entry.isDirectory())await copySourceTree(absolute,next);else if(entry.isFile())await saveSource(next,await readFile(absolute));
 }
}
for(const directory of ['tests/wormhole-wasm/vendor/magic-wormhole','licenses/upstream','licenses/release'])await copySourceTree(path.join(root,directory),directory);
await saveSource('BUILD-SOURCE.txt',`Standalone pairing candidate source

Runtime version: ${version}

This tree includes the complete modified magic-wormhole 0.8.1 crate, its
original EUPL-1.2 license, upstream provenance, and dated LOCAL-CHANGES.md.
Original first-party code uses VPL; see LICENSE and LICENSING.md. No third-party
license is replaced. The VPL/EUPL combination has unresolved compatibility;
this local review candidate does not establish permission for combined distribution.

Build prerequisites: Rust 1.99.1 with wasm32-unknown-unknown; wasm-bindgen CLI
0.2.122; Node.js; a WASM-capable C compiler for ring; tar for packaging.
The Windows wrappers expect portable Rust/GNU tools and Zig 0.15.2 under
tools/ (excluded). Install those tools there, or use your own toolchain with
the equivalent commands below. Keep .cargo/config.toml and both Cargo.lock files.
Upstream registry sources are pinned by Cargo.lock versions and checksums;
crate source archives are available from crates.io. Run from this tree's root.

Windows wrappers with their documented portable tools:
  ./build.ps1 -Prototype
  ./tests/wormhole-wasm/build.ps1
Prefetch each manifest's dependencies with cargo fetch --locked --target
wasm32-unknown-unknown when using the offline mailbox wrapper with empty caches.

Equivalent Cargo and bindings commands with Rust and wasm-bindgen on PATH
(configure CC_wasm32_unknown_unknown and AR_wasm32_unknown_unknown for ring):
  cargo build --locked --target wasm32-unknown-unknown --release
  wasm-bindgen target/wasm32-unknown-unknown/release/iroh_browser_proof.wasm --target web --out-dir prototype/wasm
  cargo build --locked --manifest-path tests/wormhole-wasm/Cargo.toml --target wasm32-unknown-unknown --release --no-default-features
  wasm-bindgen tests/wormhole-wasm/target/wasm32-unknown-unknown/release/wormhole_feasibility.wasm --target web --out-dir prototype/mailbox-wasm

JavaScript/HTML/CSS source is unminified and accompanies the running page.
To rerun the review/packager, create logs/ and generate Cargo metadata with
--locked --format-version 1 --filter-platform wasm32-unknown-unknown for the
root and tests/wormhole-wasm/Cargo.toml manifests. Save their JSON responses
as logs/iroh-release-metadata.json and logs/mailbox-release-metadata.json.
The review also checks an audit positive control: build the mailbox manifest
with --features audit and place its bindings in tests/wormhole-wasm/pkg, or
use tests/wormhole-wasm/build.ps1 -Audit. Never distribute that audit artifact.
Run node scripts/review-pairing-release.mjs --advisories, then
node scripts/package-pairing.mjs <the resulting review report path>.
Notice supplements and provenance are included at their original licenses/
paths. Recheck notice provenance if the Rust toolchain changes. This source
archive excludes compilers, private files, logs and compiled/audit WASM.
It does not promise a bit-for-bit reproducible toolchain or offline build.
`);
await save(source,'SOURCE-MANIFEST.json',JSON.stringify(sourceFiles,null,2)+'\n',[]);
await mkdir(site,{recursive:true});const archive=path.join(site,'source.tar.gz');
execFileSync('tar.exe',['-czf',archive,'-C',source,'.'],{stdio:'pipe',windowsHide:true});
const archiveBytes=await readFile(archive);files.push({path:'source.tar.gz',bytes:archiveBytes.length,sha256:sha(archiveBytes)});
await saveSite('NOTICE.txt',`Standalone Iroh/Wormhole pairing candidate\n\nThis local candidate is experimental and has not been publicly deployed.\nSource: source.tar.gz (SHA-256 ${sha(archiveBytes)}).\nRuntime version: ${version}.\n\nOriginal first-party code is licensed under the Viral Public License (VPL).\nSee LICENSE, LICENSING.md and licenses/VPL.provenance.json. The owner selected\nVPL on 2026-10-23; its text is unchanged and no exception or dual license was added.\n\nThird-party components retain their licenses, attribution and notices.\nSee THIRD-PARTY.json and licenses/. The modified magic-wormhole library remains\nEUPL-1.2; its original license, upstream provenance, complete modified source\nand dated changes are included in source.tar.gz. This is not a VPL-only bundle.\nVPL/EUPL compatibility is unresolved. No clearance for combined distribution is\nclaimed; resolve this before publication. No other project has been relicensed.\n\nStandard Apache-2.0 (enum-assoc) and Unlicense (pharos) supplements are explicitly\nidentified in the inventory; they are not recovered upstream notice files.\nRust notices are a conservative superset. The relay and mailbox operators can\nobserve connection metadata. Peer-IP protection is not Tor-like anonymity.\n`);
await saveSite('SOURCE.html','<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="referrer" content="no-referrer"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; base-uri \'none\'; form-action \'none\'"><title>Pairing source and licenses</title></head><body><h1>Source and licenses</h1><p>Original first-party code uses the Viral Public License. This is a local review candidate; compatibility with the EUPL dependency remains unresolved.</p><ul><li><a href="./LICENSE">Viral Public License</a></li><li><a href="./LICENSING.md">License scope and compatibility review</a></li><li><a href="./source.tar.gz">Corresponding source archive</a></li><li><a href="./NOTICE.txt">Notices and source archive checksum</a></li><li><a href="./THIRD-PARTY.json">Dependency licenses and attribution inventory</a></li><li><a href="./licenses/magic-wormhole-0.8.1/LICENSE">Magic Wormhole EUPL-1.2 license</a></li><li><a href="./index.html">Return to pairing</a></li></ul></body></html>');
await saveSite('HOSTING.txt',`Serve this directory over HTTPS, optionally below a subdirectory. Enable\napplication/wasm and JavaScript MIME types; serve index.html for the directory.\nGitHub Pages does not consume _headers files. Meta CSP and a restricted mailbox\nbootstrap document enforce the tested headerless policies. Additional response\nheaders should include Referrer-Policy: no-referrer, X-Content-Type-Options: nosniff,\nand frame-ancestors 'none' on index.html. Mailbox-frame.html must permit framing\nby 'self', not 'none'. Do not add CSP headers that block its blob worker.\n\nKeep index.html uncached/revalidated where supported. Files under runtime/${version}/\nare content-versioned; retain previous runtime directories while old pages may\nremain open. Content versioning prevents mixed artifact sets but cannot force a\ncache to deliver the latest entry page. Do not overwrite files within a version.\nNo service worker, paid service, PHP or Cloudflare configuration is included.\nSource/license review and actual-host policy/MIME checks remain before publication.\n`);
for(const entry of files){const actual=await readFile(safe(site,entry.path));assert.equal(actual.length,entry.bytes);assert.equal(sha(actual),entry.sha256);}
for(const entry of sourceFiles)assert.equal(sha(await readFile(safe(source,entry.path))),entry.sha256);
const manifest={createdAt:new Date().toISOString(),status:'local review candidate; not deployed',version,runtimePrefix:prefix,runtimeFiles:runtime.length,runtimeBytes:[...bytes.values()].reduce((sum,b)=>sum+b.length,0),packages:inventory.length,reviewFile,sourceArchive:{bytes:archiveBytes.length,sha256:sha(archiveBytes),files:sourceFiles.length},firstPartyLicense,firstPartyLicenseSha256:sha(licenseText),licenseReview,policies:{page:PAIRING_CSP,mailbox:MAILBOX_CSP},files};
await writeFile(path.join(output,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({output,version,runtimeFiles:runtime.length,packages:inventory.length,verifiedFiles:files.length,sourceFiles:sourceFiles.length,sourceArchiveBytes:archiveBytes.length,firstPartyLicense:manifest.firstPartyLicense}));
