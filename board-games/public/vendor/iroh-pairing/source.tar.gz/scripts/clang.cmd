@echo off
node "%~dp0cc.mjs" %*
