import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const compiler = process.env.P2P_ZIG || fileURLToPath(new URL('../tools/zig-x86_64-windows-0.15.2/zig.exe', import.meta.url));
const args = process.argv.slice(2).map(arg => arg === '--target=wasm32-unknown-unknown' ? '--target=wasm32-freestanding' : arg);
const result = spawnSync(compiler, ['cc', ...args], { stdio: 'inherit', windowsHide: true });
if (result.error) console.error(result.error.message);
process.exit(result.status ?? 1);
