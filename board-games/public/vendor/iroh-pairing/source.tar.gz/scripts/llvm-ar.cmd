@echo off
if defined P2P_ZIG (
  "%P2P_ZIG%" ar %*
) else (
  "%~dp0..\tools\zig-x86_64-windows-0.15.2\zig.exe" ar %*
)
