@echo off
"%~dp0..\tools\zig-x86_64-windows-0.15.2\zig.exe" ar %*
