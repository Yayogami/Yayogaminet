param([string]$ToolRoot = (Join-Path $PSScriptRoot 'tools'))
$ErrorActionPreference = 'Stop'
$ToolRoot = (Resolve-Path -LiteralPath $ToolRoot).Path
Set-Location -LiteralPath $PSScriptRoot
$env:RUSTUP_HOME = Join-Path $ToolRoot 'rustup'
$env:CARGO_HOME = Join-Path $ToolRoot 'cargo'
$env:LIBRARY_PATH = Join-Path $env:RUSTUP_HOME 'toolchains/stable-x86_64-pc-windows-gnu/lib/rustlib/x86_64-pc-windows-gnu/lib/self-contained'
$env:PATH = (Join-Path $ToolRoot 'w64devkit/bin') + ';' + (Join-Path $env:CARGO_HOME 'bin') + ';' + $env:PATH
$env:P2P_ZIG = Join-Path $ToolRoot 'zig-x86_64-windows-0.15.2/zig.exe'
$env:CC_wasm32_unknown_unknown = Join-Path $PSScriptRoot 'scripts/clang.cmd'
$env:AR_wasm32_unknown_unknown = Join-Path $PSScriptRoot 'scripts/llvm-ar.cmd'
$env:ZIG_GLOBAL_CACHE_DIR = Join-Path $PSScriptRoot 'build-target/zig-cache'

# Compiler diagnostic paths must not contain the builder's account or directory.
# Broad mappings come first; the later specific mappings take precedence.
$mappings = @(
  @($env:USERPROFILE, '/builder'),
  @($ToolRoot, '/tooling'),
  @($env:CARGO_HOME, '/cargo'),
  @($env:RUSTUP_HOME, '/toolchain'),
  @($PSScriptRoot, '/src')
)
$flags = @('--cfg', 'getrandom_backend="wasm_js"')
foreach ($mapping in $mappings) {
  if (-not $mapping[0]) { continue }
  $prefix = [string]$mapping[0]
  $flags += '--remap-path-prefix=' + $prefix + '=' + $mapping[1]
  $flags += '--remap-path-prefix=' + $prefix.Replace('\','/') + '=' + $mapping[1]
}
$env:CARGO_ENCODED_RUSTFLAGS = $flags -join [char]31
$env:CFLAGS_wasm32_unknown_unknown = '-ffile-prefix-map="' + $PSScriptRoot + '"=/src -ffile-prefix-map="' + $env:USERPROFILE + '"=/builder'
$cargo = Join-Path $env:CARGO_HOME 'bin/cargo.exe'
$bindgen = Join-Path $ToolRoot 'wasm-bindgen/wasm-bindgen.exe'
$target = Join-Path $PSScriptRoot 'build-target'
foreach ($build in @(
  @('Cargo.toml', 'iroh_browser_proof', 'prototype/wasm'),
  @('tests/wormhole-wasm/Cargo.toml', 'wormhole_feasibility', 'prototype/mailbox-wasm')
)) {
  & $cargo build --locked --offline --manifest-path $build[0] --target wasm32-unknown-unknown --release --no-default-features --target-dir $target
  if ($LASTEXITCODE -ne 0) { throw 'Private-path Cargo build failed' }
  & $bindgen (Join-Path $target ('wasm32-unknown-unknown/release/' + $build[1] + '.wasm')) --target web --out-dir $build[2]
  if ($LASTEXITCODE -ne 0) { throw 'Private-path bindings failed' }
}
Write-Output 'Both transport modules rebuilt with neutral paths and namespaces.'
