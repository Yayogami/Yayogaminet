param([switch]$AuditPeer, [switch]$AddressAudit, [switch]$Prototype)
$ErrorActionPreference = 'Stop'
if ($AuditPeer -and $AddressAudit) { throw 'Choose only one audit build' }
if ($Prototype -and ($AuditPeer -or $AddressAudit)) { throw 'Choose only one build mode' }
Set-Location $PSScriptRoot
$env:RUSTUP_HOME = Join-Path $PSScriptRoot 'tools/rustup'
$env:CARGO_HOME = Join-Path $PSScriptRoot 'tools/cargo'
$env:LIBRARY_PATH = Join-Path $PSScriptRoot 'tools/rustup/toolchains/stable-x86_64-pc-windows-gnu/lib/rustlib/x86_64-pc-windows-gnu/lib/self-contained'
$env:CC_wasm32_unknown_unknown = Join-Path $PSScriptRoot 'scripts/clang.cmd'
$env:AR_wasm32_unknown_unknown = Join-Path $PSScriptRoot 'scripts/llvm-ar.cmd'
$env:ZIG_GLOBAL_CACHE_DIR = Join-Path $PSScriptRoot 'tools/zig-cache'
$env:PATH = (Join-Path $PSScriptRoot 'tools/w64devkit/bin') + ';' + (Join-Path $PSScriptRoot 'tools/cargo/bin') + ';' + $env:PATH
$buildArguments = @('build', '--locked', '--target', 'wasm32-unknown-unknown', '--release')
$artifact = 'iroh_browser_proof'
$outputDirectory = 'public/wasm'
if ($Prototype) { $outputDirectory = 'prototype/wasm' }
if ($AuditPeer) {
  $buildArguments += @('--manifest-path', 'tests/adversary/Cargo.toml', '--target-dir', 'target')
  $artifact = 'audit_peer'
  $outputDirectory = 'tests/adversary/pkg'
}
if ($AddressAudit) {
  & node tests/prepare-address-audit.mjs
  if ($LASTEXITCODE -ne 0) { throw 'Address audit preparation failed' }
  $buildArguments += @('--manifest-path', 'tests/address-audit/Cargo.toml', '--target-dir', 'target')
  $artifact = 'address_audit'
  $outputDirectory = 'tests/address-audit/pkg'
}
& cargo @buildArguments
if ($LASTEXITCODE -ne 0) { throw 'Cargo build failed' }
& "$PSScriptRoot/tools/wasm-bindgen/wasm-bindgen.exe" "target/wasm32-unknown-unknown/release/$artifact.wasm" --target web --out-dir $outputDirectory
if ($LASTEXITCODE -ne 0) { throw 'WASM bindings failed' }
